export let nom1 = 'abc';
